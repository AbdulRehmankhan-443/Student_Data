import pandas as pd
import mysql.connector

# MySQL database configuration
db_config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'student'
}

def insert_csv_to_db(csv_file_path):
    # Read the CSV file into a DataFrame
    data = pd.read_csv(csv_file_path)

    # Establish a database connection
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()

    # Prepare the SQL insert statement
    insert_query = """
        INSERT INTO student_table (id , name, class, section, email, phone, fees) 
        VALUES (%s,%s, %s, %s, %s, %s, %s)
    """

    # Insert data into the database
    for index, row in data.iterrows():
        cursor.execute(insert_query, tuple(row))

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()

if __name__ == "__main__":
    csv_file_path = 'C:\\xampp1\\htdocs\\Student project\\Student (2).csv'  # Update this with the path to your CSV file
    insert_csv_to_db(csv_file_path)
    print("Data inserted successfully.")
