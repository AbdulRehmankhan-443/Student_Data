from flask import Flask, render_template, request, flash
import mysql.connector

app = Flask(__name__)
app.secret_key = 'your_secret_key'  

# MySQL database configuration
db_config = {
    'user': 'root',
    'password': '',
    'host': 'localhost',
    'database': 'student'
}

@app.route('/', methods=['GET', 'POST'])
def index():
    student_data = None
    error_message = None
    if request.method == 'POST':
        student_id = request.form.get('student_id')
        student_data = get_student_data(student_id)
        if student_data is None:
            error_message = "Student ID not found. Please try again."
    return render_template('index.html', student_data=student_data, error_message=error_message)

def get_student_data(student_id):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM student_table WHERE id = %s", (student_id,))
        student = cursor.fetchone()
        return student
    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

if __name__ == '__main__':
    app.run(debug=True)
